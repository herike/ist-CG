class MyVector {

    constructor(x,y,z) {
    	'use strict';
        this.x=x;
        this.y=y;
        this.z=z;
    }

    set(x,y,z) {
        'use strict';
        this.x=x;
        this.y=y;
        this.z=z;
    }
}
